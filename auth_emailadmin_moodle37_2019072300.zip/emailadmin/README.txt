moodle-auth_emailadmin
======================

Moodle plugin to provide email self-registration with admin confirmation.

The confirmation email is sent to the main admin account's email address.

When the admin clicks on the confirmation link, a "welcome" email is sent to the user.

Email body is customizable within the language file.

Based on default email-based self-registration module.

***Please read the INSTALL file carefully***
